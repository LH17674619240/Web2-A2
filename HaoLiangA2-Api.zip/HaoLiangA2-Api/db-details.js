module.exports = {
    host: "localhost",
    user: "root",
    password: "123456789",
    database : "crowdfunding_db"
  };